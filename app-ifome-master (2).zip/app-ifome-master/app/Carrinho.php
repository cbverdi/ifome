<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carrinho extends Model
{
    protected $table = 'carrinho';

    protected $fillable = [
        'cod_produto', 'nome', 'preco', 'nome_loja', 'img', 'peso', 'quantidade'
    ];

}
