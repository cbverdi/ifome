<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index()
    {
        return"exibindo lista de clientes";
    }
    //---------------------------------


    public function update($id)
    {
        return"Editando informaçoes de um cliente: {$id}";
    }


}
