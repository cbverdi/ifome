<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    
    public function index()
    {
        return view('register'); 
    }

    public function home()
    {
        return view('home'); 
    }

    public function login()
    {
        return view('pages.login'); 
    }
    public function registo()
    {
        return view('pages.registo'); 
    }

    public function perfil()
    {
        return view('pages.client.perfil'); 
    }

    public function settings()
    {
        return view('pages.settings'); 
    }

    public function cart()
    {
        return view('pages.cart'); 
    }

    public function notification()
    {
        return view('pages.client.notification'); 
    }



}
