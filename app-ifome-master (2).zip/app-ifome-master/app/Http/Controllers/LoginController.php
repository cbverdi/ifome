<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index()
    {

        $teste = '<h1> testando a tag!</h1>';

        return view('pages',compact('teste'));
        
    }

    public function cadastro()
    {
        return 'página de cadastra clientes';
    }
}
