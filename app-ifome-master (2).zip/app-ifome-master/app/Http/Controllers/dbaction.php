<?php



use Illuminate\Http\Request;



function validarsessiontoken($UID){


}

function replaceSpecialChars($palavra){
    $output = '';
    $chars = array('Ã£' => 'ã',
                   'Ã¡' => 'á',
                   'Ã ' => 'à',
                   'Ã¤' => 'ä',
                   'Ã¢' => 'â'
                   //eq1
                   ,'Ã©' => 'é'
                   ,'Ã¨' => 'è'
                   ,'Ã«' => 'ë'
                   ,'Ãª' => 'ê'
                    //i
                   ,'Ã­' => 'í'
                   ,'Ã¬' => 'ì'
                   ,'Ã¯' => 'ï'
                   ,'Ã®' => 'î'
                   //o
                   ,'Ãµ' => 'õ'
                   ,'Ã³' => 'ó'
                   ,'Ã²' => 'ò'
                   ,'Ã¶' => 'ö'
                   ,'Ã´' => 'ô'
                   //u
                   ,'Ãº' => 'ú'
                   ,'Ã¹' => 'ù'
                   ,'Ã¼' => 'ü'
                   //ç
                   ,'Ã§' => 'ç');
    
    foreach ($chars as $key => $value) {
        $output = str_replace($value,$key,$palavra);
    }
    
    return $output;
}



function startConnection($servername, $username, $password, $dbname)
{
    // Create connection
    global $conn;
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
}

function normalizarTexto($texto = ''){
    return preg_replace('~&([a-z]{1,2})(?:acute|cedil|circ|grave|lig|orn|ring|slash|th|tilde|uml|caron);~i', '$1', htmlentities($texto, ENT_COMPAT, 'UTF-8'));
}


function limpaTexto($string) {
    return str_replace('"','&quot;',str_replace('\'','&#39;',$string)); 
}


function generateInsertQuery($data)
{
    $strColumns = '';
    $strValues = '';
    foreach($data as $key => $value) {
        $strValues = $strValues . '"'.limpaTexto($data[$key]).'"' . ', ';
        $strColumns = $strColumns . $key . ', ';
    }
    return '('.substr($strColumns, 0,  strlen($strColumns)-2).') VALUES ('.substr($strValues, 0,  strlen($strValues)-2).')';
}


function generateUpdateQuery($data, $separador = ', ')
{
    $output = '';
    
    foreach($data as $key => $value) {
        $output .= $key.'="'.limpaTexto($value).'"' . $separador;
    }
    return ($separador === ', ') ? substr($output, 0,  strlen($output)-2) : substr($output, 0,  strlen($output)-4);
}

function insertData($tableName, $data)
{
    global $conn;

    
    $servername = "localhost";
    $port=3306;
    $socket="";
    $username="root";
    $password="";
    $dbname="ifome_mydb";

        
        startConnection($servername, $username, $password, $dbname);

        if(!empty($tableName))
        {
            $sql = 'INSERT INTO ' .$dbname. '.'.$tableName. generateInsertQuery($data);

        // $msg = $sql;

         $msg = ($conn->query($sql) === TRUE) ? "true": "false";
                                            
        return $msg;
        }
        closeConnection();
}

function insertData_teste($tableName, $data)
{
    global $conn;

    
    $servername = "localhost";
    $port=3306;
    $socket="";
    $username="root";
    $password="";
    $dbname="ifome_mydb";

        
        startConnection($servername, $username, $password, $dbname);

        if(!empty($tableName))
        {
            $sql = 'INSERT INTO ' .$dbname. '.'.$tableName. generateInsertQuery($data);

          $msg = $sql;

      //  $msg = ($conn->query($sql) === TRUE) ? "true": "false";
                                            
        return $msg;
        }
        closeConnection();
}


function insertDatagetlastid($tableName, $data)
{
    global $conn;

    
    $servername = "localhost";
    $port=3306;
    $socket="";
    $username="root";
    $password="";
    $dbname="ifome_mydb";

        
        startConnection($servername, $username, $password, $dbname);

        if(!empty($tableName))
        {
            $sql = 'INSERT INTO ' .$dbname. '.'.$tableName. generateInsertQuery($data);

        //   $msg =  $sql;

            $msg =  ($conn->query($sql) === TRUE) ? mysqli_insert_id($conn) : 0;
    

        return $msg;
        }
        closeConnection();
    }


function closeConnection()
{
    global $conn;
    
    if (isset($conn)) {
        $conn->close();
    }
}

function fetchTableContent($tableName, $whereClause, $columns = '*')
{



    global $conn;
    $servername = "localhost";
    $port=3306;
    $socket="";
    $username="root";
    $password="";
    $dbname="ifome_mydb";



    startConnection($servername, $username, $password, $dbname);


    if(!empty($tableName))
    {
         $sql = 'SELECT '.$columns.' FROM ' .$dbname. '.'.$tableName.' '.$whereClause;

         $output =  $conn->query($sql);
        //var_dump($output);
    }
    closeConnection();
    
    return     $output;
}
function getSysDate()
{
  
    return date("yy-m-d H:i:s",strtotime('-1 Hours')) ;
}

function updateData($tableName, $data, $clause)
{
    
    global $conn;
    $servername = "localhost";
    $port=3306;
    $socket="";
    $username="root";
    $password="";
    $dbname="ifome_mydb";
    
    startConnection($servername, $username, $password, $dbname);


    if(!empty($tableName))
    {
        $sql = 'UPDATE ' .$dbname. '.'.$tableName.' SET '. generateUpdateQuery($data) .' WHERE '. $clause;

       // $msg =  $sql ;
        
       $msg = ($conn->query($sql) === TRUE) ? "SAVE_OK"     : "SAVE_ERR";
    }
    //echo $conn->error;
    closeConnection();
    
    return $msg;
}

?>