<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use phpDocumentor\Reflection\Types\This;
use Symfony\Component\HttpFoundation\Session\Flash\FlashBag;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\dbaction;
use App\carrinho;
use Ramsey\Uuid\Type\Decimal;
use Cart;
use Session;


class routesController extends Controller 
{

   public static function getProdutosPopulares(){


         for ($i = 1; $i <= 1; $i++) {

            $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getProdutoListbyentidadeWebApp&identidade=2&token=D5FE7C33B7BCD2823685DFB69A4A2A64');
         
            $produtosPopulares = json_decode($str, true); 
        }
   
      return $produtosPopulares;
   
   }


   public static function getNegocios(){

      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getentidadetype&token=D5FE7C33B7BCD2823685DFB69A4A2A64&fbclid=IwAR2ic_vP-96qDiioVC44ce26ms587JtC2EscSx7k-9F-dLpA6A0kIkQxtAc');
      
         $negocios = json_decode($str, true); 
         
     }
     return $negocios;
   }


   public static function getProdutosByNegocios(){

      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getentListbytype&idtype=2&token=D5FE7C33B7BCD2823685DFB69A4A2A64');
      
         $produtosNegocios = json_decode($str, true); 
         
     }
      return $produtosNegocios;
   }

  
   public function home()
   {
        $imagem = ['img/bg-img/img1.jpg','img/bg-img/img4.jpg','img/bg-img/img5.jpg'];       



     
       
      $stockLimitado = ['img/product/1.png','img/product/2.png','img/product/3.png','img/product/1.png','img/product/2.png','img/product/3.png'];

         $produtosNegocios = self::getProdutosByNegocios();
         $produtosPopulares = self::getProdutosPopulares();
         $negocios = self::getNegocios();

         //dd($negocios);
         //dd($produtosNegocios);
         //dd($produtosPopulares);
         

        return view('home', compact('imagem','stockLimitado','produtosPopulares', 'negocios')); 
   }


   public function login()
   {
      return view('pages.login'); 
   }
   public function registo()
   {
      return view('register'); 
   }

   public function perfil()
   {
      return view('pages.client.perfil'); 
   }

   public function settings()
   {
      return view('pages.settings'); 
   }

   public function cart()
   {
      return view('pages.cart'); 
   }

   public function detalhedoproduto($id)
   {
        

      //$detalhes = self::getProdutosPopulares();

      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getProdutoListbyentidadeWebApp&identidade=1&token=D5FE7C33B7BCD2823685DFB69A4A2A64');
      
         $detalhes = json_decode($str, true); 
     }

      //dd($detalhes);
      
      $retornaArra = [];

      foreach ($detalhes as $value) {
         // echo "<pre>";
         //print_r($value);
         if($value['cod_produto'] == $id){
            $retornaArra[] = $value;
         }
      }

      //dd($retornaArra);
   

      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getentidadetype&token=D5FE7C33B7BCD2823685DFB69A4A2A64&fbclid=IwAR2ic_vP-96qDiioVC44ce26ms587JtC2EscSx7k-9F-dLpA6A0kIkQxtAc'.$i);
      
         $negocios = json_decode($str, true);
         //dd($negocios);
         
      }

      $link ='[{
            "valor":"0",
            "descrisao":"Recentes",
            "url":"http://www.google.com"    
         },
         
         {
            "valor":"1",
            "descrisao":"Frescos",
            "url":"http://www.facebook.com" 
         }, 
         {
            "valor":"2",
            "descrisao":"Congelados",
            "url":"http://www.facebook.com" 
         },
         {
            "valor":"4",
            "descrisao":"Mercearia",
            "url":"http://www.facebook.com" 
         },  
         {
            "valor":"3",
            "descrisao":"Saude&Beleza",
            "url":"http://www.facebook.com" 
         }]';
         
      $links = json_decode($link, true); 
         

      $entidade ='[{
            "valor":"0",
            "descrisao":"Supermercado",
            "link":"http://www.google.com"    
         },
         
         {
            "valor":"2",
            "descrisao":"Restaurante",
            "link":"http://www.facebook.com" 
         }, 
         {
            "valor":"1",
            "descrisao":"Farmacias",
            "link":"http://www.facebook.com" 
         },
         {
            "valor":"4",
            "descrisao":"Lojas",
            "link":"http://www.facebook.com" 
         },  
         {
            "valor":"3",
            "descrisao":"Peixaria",
            "link":"http://www.facebook.com" 
         }, 
         
         {
            "valor":"5",
            "descrisao":"Frescos Agrículas",
            "link":"http://www.youtube.com"
         }]';
   
               
      $entidades = json_decode($entidade, true); 
         //dd($entidades);
         //dd(gettype($entidades));

      
      $produtos_relacionado= '[{
            "id":"0",
            "nome":"Lámpada de Mesa",
            "imagem":"img/product/1.png",
            "preco_real":"750 ECV",   
            "preco_venda":"525 ECV"   
         },
         {
            "id":"1",
            "nome":"Sufá Moderna",
            "imagem":"img/product/2.png",
            "preco_real":"11.500 ECV",   
            "preco_venda":"10.620 ECV"
         },
         {
            "id":"2",
            "nome":"cadeira Clássica",
            "imagem":"img/product/3.png",
            "preco_real":"7.500 ECV",   
            "preco_venda":"6.525 ECV"
         },
         {
            "id":"3",
            "nome":"Lámpada de Mesa",
            "imagem":"img/product/1.png",
            "preco_real":"750 ECV",   
            "preco_venda":"525 ECV"
         },
         {
            "id":"4",
            "nome":"Sufá Moderna",
            "imagem":"img/product/2.png",
            "preco_real":"10.050 ECV",   
            "preco_venda":"9.525 ECV"
         }]';

      $produtos_relacionados = json_decode($produtos_relacionado, true); 
      //dd($produtos_relacionados);
      //dd(gettype($produtos_relacionados));

         //dd($retornaArra);

      return view('pages.detalheDoProduto', compact('entidades','produtos_relacionados','links','negocios','detalhes','retornaArra')); 
   }

   //--------------------------------------------------------------------------------------



   public function add(Request $request)
   {

  
      Cart::add(
         $request->cod_produto, 
         $request->nome, 
         $request->quantidade, 
         $request->preco_venda, 
         $request->peso, 
         [ 'nomeLoja'=> $request->nome_loja, 'img' =>$request->img ]
      );

      Cart::content();
      

      

      // $user = Carrinho::create([
      //    'cod_produto' => $request->cod_produto,
      //    'nome' => $request->nome,
      //    'preco' => (float)$request->preco_venda,
      //    'nome_loja' => $request->nome_loja,
      //    'img' => $request->img,
      //    'peso' => $request->peso,
      //    'quantidade' => $request->quantidade,
      // ]);

   

      return response()->json([
         'status' => 'Item adicionado ao carrinho com sucesso :)',
         'qty' => Cart::instance('default')->count(),
         'subtotalCompras' =>  Cart::subtotal(),
         'totalCompras' =>  Cart::total(),
         'modifica' => "deucerto"
     ], 200);
      
   }

   public function remove($rowId){

      Cart::remove($rowId);
      
      Session::flash('retorno', 'produto removido !'); 

      return redirect()->route('meucarrinho.index');
   }


   public function landingPage()
   {
         $negocio ='[{
               "valor":"2",
               "descrisao":"Comidas",
               "img":"img/bg-img/icon/img1.png",
               "link":"http://www.facebook.com"    
            },
            
            {
               "valor":"5",
               "descrisao":"Entregas",
               "img":"img/bg-img/icon/img7.png",
               "link":"http://www.facebook.com" 
            }, 
            {
               "valor":"2",
               "descrisao":"Restaurantes",
               "img":"img/bg-img/icon/img9.png",
               "link":"http://www.facebook.com" 
            },
            {
               "valor":"4",
               "descrisao":"Grocerias",
               "img":"img/bg-img/icon/img4.png",
               "link":"http://www.facebook.com" 
            },  
            {
               "valor":"1",
               "descrisao":"Farmácias",
               "img":"img/bg-img/icon/img8.png",
               "link":"http://www.facebook.com" 
            }, 
            
            {
               "valor":"0",
               "descrisao":"SuperMercados",
               "img":"img/bg-img/icon/img3.png",
               "link":"http://www.youtube.com"
            },  
            {
               "valor":"9",
               "descrisao":"Cafés & Lanches",
               "img":"img/bg-img/icon/img2.png",
               "link":"http://www.facebook.com" 
            }]';
         //dd($negocio);
               
         $negocios = json_decode($negocio, true); 
         //dd($negocios);
         //dd(gettype($negocios));

      return view('pages.landingPage',compact('negocios')); 
   }

//-------------------------------------------------------------------------------------------------------

   public function meucarrinho()
   {
      $cart = session()->has('cart') ? session()->get('cart') : [];

      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getentidadetype&token=D5FE7C33B7BCD2823685DFB69A4A2A64&fbclid=IwAR2ic_vP-96qDiioVC44ce26ms587JtC2EscSx7k-9F-dLpA6A0kIkQxtAc'.$i);
      
         $negocios = json_decode($str, true); 
     }

      return view('pages.cartDetail', compact('cart', 'negocios')); 
   }

   public function incrementa($rowId, $qty)
   {
      Cart::update($rowId, $qty); // Will update the quantity
      $item = Cart::get($rowId);
      
      return response()->json([
          'qty' => Cart::instance('default')->count(),
          'status' => 'quantidade Atualizado :)',
          'totalProduto' => ($item->price * $item->qty),
          'totalCompras' => Cart::subtotal(),
          'totalTotal' => Cart::total()
      ], 200);
  }
    

  public function negocios($id){
      $produtosNegocios = self::getProdutosByNegocios();
      $produtosPopulares = self::getProdutosPopulares();
      $negocios = self::getNegocios();

      $link ='[{
            "valor":"0",
            "descrisao":"Recentes",
            "url":"http://www.google.com"    
         },
         
         {
            "valor":"1",
            "descrisao":"Frescos",
            "url":"http://www.facebook.com" 
         }, 
         {
            "valor":"2",
            "descrisao":"Congelados",
            "url":"http://www.facebook.com" 
         },
         {
            "valor":"4",
            "descrisao":"Mercearia",
            "url":"http://www.facebook.com" 
         },  
         {
            "valor":"3",
            "descrisao":"Saude&Beleza",
            "url":"http://www.facebook.com" 
         }]';
      
      $links = json_decode($link, true); 

      $arrayDeProdutos = [];

      foreach ($produtosNegocios as $value) {
         
         if($value['tipoentidade'] == $id){
            $arrayDeProdutos[] = $value;
         }

      }

      foreach ($negocios as $value) {
         
         if($value['valor'] == $id){
            $nomeNegocio[] = $value;
         }

      }

      

   return view('negocios', compact('negocios', 'links', 'arrayDeProdutos','nomeNegocio'));
  }


  
  public function produtosDosNegocios($id)
   {

      $produtosNegocios = self::getProdutosByNegocios();
      //$produtosPopulares = self::getProdutosPopulares();
      $negocios = self::getNegocios();

 
      for ($i = 1; $i <= 1; $i++) {

         $str = file_get_contents('http://www.ifome.cv/marketplace/api/apiweb.php?tipo=getProdutoListbyentidadeWebApp&identidade='.$id.'&token=D5FE7C33B7BCD2823685DFB69A4A2A64');
      
         $produtosPopulares = json_decode($str, true); 
     }
     

      $arrayDeProdutos1 = [];
      $arrayDeProdutos2 = [];
      $arrayDeProdutos3 = [];
      $arrayDeProdutos4 = [];

      foreach ($produtosPopulares as $value) {

         if ($value['categoria'] == 'comida') 
         {
            $arrayDeProdutos1[] = $value;
         }else
         if ($value['categoria'] == 'B') 
         {
            $arrayDeProdutos2[] = $value;        
         }else
         if ($value['categoria'] == 'S') 
         {
            $arrayDeProdutos3[] = $value;        
         }else
         if ($value['categoria'] == 'P') 
         {
            $arrayDeProdutos4[] = $value;        
         }
      }

     
      //dd($arrayDeProdutos2);
      //dd($produtosPopulares);



      $imagem = ['img/bg-img/img10.jpg','img/bg-img/img14.jpg','img/bg-img/img1.jpg','img/bg-img/img5.jpg'];

      $stockLimitado = ['img/product/1.png','img/product/2.png','img/product/3.png','img/product/1.png','img/product/2.png','img/product/3.png'];

      return view('produtosDosNegocios', compact('negocios','imagem','stockLimitado','produtosPopulares','arrayDeProdutos1', 'arrayDeProdutos2','arrayDeProdutos3','arrayDeProdutos4')); 
   }

   

    

}