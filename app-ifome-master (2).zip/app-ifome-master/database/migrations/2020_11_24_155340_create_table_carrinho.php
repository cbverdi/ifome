<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableCarrinho extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carrinho', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('cod_produto');
            $table->string('nome', 40);
            $table->string('nome_loja',50);
            $table->double('preco', 8, 2);
            $table->string('img');
            $table->double('peso', 8, 2);
            $table->string('quantidade');
            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carrinho');
    }
}
