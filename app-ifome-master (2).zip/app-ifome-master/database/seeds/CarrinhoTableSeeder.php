<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CarrinhoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('carrinho')->insert(
            [ 
                'nome' => 'cadeira34',
                'nome_loja' => 'Loja armindo',
                'preco' => '54500',
            ]
        );
    }
}
