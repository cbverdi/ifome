$(".addCarrinhoForm").submit(function (e) { 
    e.preventDefault();

    let idProduto = $(this).attr('data-idproduto')
    let url = $(this).attr('action')
    let dados = $(this).serialize()

    
    addProdutoCarrinho(url, dados);
});


function addProdutoCarrinho(url, dados) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: 'json',
        data: dados,
        beforeSend: function (request) {
            return request.setRequestHeader('X-CSRF-Token', $("meta[name='csrf-token']").attr('content'));
        },
        success: function (response) {
            console.log("sucesso ");
            if (response.modifica === 'deucerto') {
                $("#contadorCarrinho").html(response.qty)
                toastr["success"]("produto adicionado com sucesso!", "Adicionar ao carrinho");
            }
            // else {
            //     alertify.success(response.status);
            //     $("#contadorCarrinho").html(response.qty)
            //     $("#contadorCarrinhoCategoria").html(`<i class="fa fa-shopping-cart" style=""></i> `+response.qty)
                
            // }
        },
        error: function (error) {
            console.log('erro no cadastro');
        }
    });
}

function diminuirQuantidade(input, rowId){
    let valorInput = parseInt(input.value)-1
    if (valorInput == -1) {
        valorInput = 1
    }
    //input.stepDown()
    let url = `meucarrinho/atualizaQty/${rowId}/${valorInput}`
    atualizaQty(url)
}

function aumentarQuantidade(input, rowId){

    let qty = parseInt(input.value)+1
    let url = `meucarrinho/atualizaQty/${rowId}/${qty}`
    atualizaQty(url)
}

    function atualizaQty(url){
        $.ajax({
            url: url,
            type: "POST",
            dataType: 'json',
            beforeSend: function (request) {
                return request.setRequestHeader('X-CSRF-Token', $("meta[name='csrf-token']").attr('content'));
            },
            success: function (response) {
                console.log("sucesso ");
                toastr.success(response.status);
                $("#contadorCarrinho").html(response.qty)
                $("#subTotalCompra").html(response.subtotalCompras)
                $("#TotalCompra").html(response.totalCompras)
                // $(`#total_${itemId}`).html(response.totalProduto)
                // let valor = response.totalTotal
                // valor = valor.split(',').join("");
                // let total = (parseInt(valor)+150)
                // $("#totalGeral").html(total+"$")
            },
            error: function (error) {
                console.log('erro no cadastro');
            }
        });
    }