@extends('layouts.app')    

@section('title')
    ifome - Home
@endsection  

@section('header')

    <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
        <div class="col-1">
            
        </div>
        @foreach ($negocios as $item)                    
            <div class=" col" style="border-right: solid 1px white;">
                <a href="{{ route('negocios', $item['valor']) }}"><span> {{$item['descrisao']}} </span></a>
            </div>
        @endforeach
       
        <div class="col-1">
            
        </div>
        <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
    </div>
    
    <div class="row header-area-1 testando">
        
        <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
            <span></span><span></span><span></span>
        </div>

        <div class="col-1 logo-wrapper ">
            <a href="{{route('home')}}"><img src="{{asset('img/bg-img/core-img/logo4.png')}}" alt=""></a>
        </div>
        <!-- Search Form-->
        <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
            <form action="" method="">
                <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
        <!-- Navbar Toggler-->
        <div class="col justify-content-between">
            <i class="lni lni-world"></i>
            linguagem
        </div>
        <div class=" col ">
            <i class=" lni lni-user "></i>
            Minha Conta
        </div>
        <div class=" col ">
            <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
            <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
            {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                Cart
            </a>
        </div>
    </div>
@endsection  

@section('content')
    <div class="container">
        
        
        <!-- PWA Install Alert-->
        
        <div class="page-content-wrapper">
        <!-- Hero Slides-->
        <div class="hero-slides owl-carousel">

            
        @foreach ($imagem as $item)
            <div class="single-hero-slide" style="background-image: url({{$item}})">
                <div class="slide-content h-100 d-flex align-items-center">
                    <div class="container">
                        <h4 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-wow-duration="1000ms">Nome Produto</h4>
                        <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-wow-duration="1000ms">detalhe, preço</p><a class="btn btn-primary btn-sm" href="#" data-animation="fadeInUp" data-delay="800ms" data-wow-duration="1000ms">compre agora</a>
                    </div>
                </div>
            </div>
        @endforeach

         
        </div>
        
        
        <!-- Top Products-->
        <div class="top-products-area clearfix py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Produtos Populares</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">

                    @foreach ($produtosPopulares as $produto)
                    
                        <div class="col-6 col-md-4 col-lg-3">
                            <div class="card top-product-card">
                                <div class="card-body"><span class="badge badge-danger">-15%</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"><img class="mb-2" src="{{asset($produto['img'])}}" alt=""></a><a class="product-title d-block" href="single-product">{{$produto['nome']}}</a>
                                    <p class="sale-price">{{$produto['preco_real']}}<span>{{$produto['preco_venda']}}</span></p>
                                    <div class="product-rating"><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i></div>
                                    
                                    <form class="addCarrinhoForm" data-idproduto="{{$produto['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                                        @csrf
                                        <input type="hidden" name="cod_produto" value="{{$produto['cod_produto']}}">
                                        <input type="hidden" name="nome"value="{{$produto['nome']}}">
                                        <input type="hidden" name="nome_loja"value="{{$produto['nome_loja']}}">
                                        <input type="hidden" name="preco_venda"value="{{$produto['preco_venda']}}">
                                        <input type="hidden" name="img"value="{{$produto['img']}}">
                                        <input type="hidden" name="peso"value="{{$produto['peso']}}">
                                        <input type="hidden" name="quantidade" value="1">
                                        <button class="btn btn-success btn-sm"><i class="lni lni-plus"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        <!-- Cool Facts Area-->
        <div class="cta-area">
            <div class="container">
                <div class="cta-text p-4 p-lg-5" style="background-image: url(img/bg-img/24.jpg)">
                    <h4>promoçoes de venda com 50% de desconto</h4>
                    <p>Mais detalhes... &amp; <br>mais detalhes.</p><a class="btn btn-danger" href="#">Compre agora</a>
                </div>
            </div>
        </div>
        <!-- Weekly Best Sellers-->
        <div class="weekly-best-seller-area py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="pl-1">Mais vendidos da semana</h6><a class="btn btn-success btn-sm" href="shop-list.html">Ver todos</a>
                </div>
            <div class="row g-3">
                <!-- Single Weekly Product Card-->
                @foreach ($produtosPopulares as $produto)
                    <div class="col-12 col-md-6">
                        <div class="card weekly-product-card">
                            <div class="card-body d-flex align-items-center">
                                <div class="product-thumbnail-side"><span class="badge badge-success">Sale</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"><img src="{{asset($produto['img'])}}" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Modern Red Sofa</a>
                                    <p class="sale-price"><i class="lni lni-dollar"></i>$64<span>$89</span></p>
                                    <div class="product-rating"><i class="lni lni-star-filled"></i>4.88 (39)</div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="mr-1 lni lni-cart"></i>Compre Agora</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                <!-- Single Weekly Product Card-->
                {{-- <div class="col-12 col-md-6">
                <div class="card weekly-product-card">
                    <div class="card-body d-flex align-items-center">
                    <div class="product-thumbnail-side"><span class="badge badge-primary">Sale</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/7.png" alt=""></a></div>
                    <div class="product-description"><a class="product-title d-block" href="single-product.html">Office Chair</a>
                        <p class="sale-price"><i class="lni lni-dollar"></i>$100<span>$160</span></p>
                        <div class="product-rating"><i class="lni lni-star-filled"></i>4.82 (125)</div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="mr-1 lni lni-cart"></i>Buy Now</a>
                    </div>
                    </div>
                </div>
                </div>
                <!-- Single Weekly Product Card-->
                <div class="col-12 col-md-6">
                <div class="card weekly-product-card">
                    <div class="card-body d-flex align-items-center">
                    <div class="product-thumbnail-side"><span class="badge badge-danger">-10%</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/12.png" alt=""></a></div>
                    <div class="product-description"><a class="product-title d-block" href="single-product.html">Sun Glasses</a>
                        <p class="sale-price"><i class="lni lni-dollar"></i>$24<span>$32</span></p>
                        <div class="product-rating"><i class="lni lni-star-filled"></i>4.79 (63)</div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="mr-1 lni lni-cart"></i>Buy Now</a>
                    </div>
                    </div>
                </div>
                </div>
                <!-- Single Weekly Product Card-->
                <div class="col-12 col-md-6">
                <div class="card weekly-product-card">
                    <div class="card-body d-flex align-items-center">
                    <div class="product-thumbnail-side"><span class="badge badge-warning">New</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/13.png" alt=""></a></div>
                    <div class="product-description"><a class="product-title d-block" href="single-product.html">Wall Clock</a>
                        <p class="sale-price"><i class="lni lni-dollar"></i>$31<span>$47</span></p>
                        <div class="product-rating"><i class="lni lni-star-filled"></i>4.99 (7)</div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="mr-1 lni lni-cart"></i>Buy Now</a>
                    </div>
                    </div>
                </div>
                </div> --}}
            </div>
            </div>
        </div>
        <!-- Discount Coupon Card-->
        <div class="container">
            <div class="card discount-coupon-card border-0">
            <div class="card-body">
                <div class="coupon-text-wrap d-flex align-items-center p-3">
                <h5 class="text-white pr-3 mb-0">Obtenha 20%<br>de disconto</h5>
                <p class="text-white pl-3 mb-0">detalhar informaçoes sobre<strong class="px-1">desconto</strong>na compra.</p>
                </div>
            </div>
            </div>
        </div>
        <!-- Featured Products Wrapper-->
        <div class="featured-products-wrapper py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="pl-1">Produtos em destaque</h6><a class="btn btn-warning btn-sm" href="featured-products.html">Ver todos</a>
                </div>
                <div class="row g-3">
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card featured-product-card">
                            <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                                <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/14.png" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Blue Skateboard</a>
                                    <p class="sale-price">$64<span>$89</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                    <div class="card featured-product-card">
                        <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                        <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/15.png" alt=""></a></div>
                        <div class="product-description"><a class="product-title d-block" href="single-product.html">Travel Bag</a>
                            <p class="sale-price">$64<span>$89</span></p>
                        </div>
                        </div>
                    </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                    <div class="card featured-product-card">
                        <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                        <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/16.png" alt=""></a></div>
                        <div class="product-description"><a class="product-title d-block" href="single-product">Cotton T-shirts</a>
                            <p class="sale-price">$64<span>$89</span></p>
                        </div>
                        </div>
                    </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card featured-product-card">
                            <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                                <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/6.png" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Roof Lamp </a>
                                    <p class="sale-price">$64<span>$89</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Night Mode View Card-->
        <div class="night-mode-view-card pb-3">
            <div class="container">
            <div class="card settings-card">
                <div class="card-body">
                <div class="single-settings d-flex align-items-center justify-content-between">
                    <div class="title"><i class="lni lni-night"></i><span>Modo Noturno</span></div>
                    <div class="data-content">
                    <div class="toggle-button-cover">
                        <div class="button r">
                        <input class="checkbox" id="darkSwitch" type="checkbox">
                        <div class="knobs"></div>
                        <div class="layer"></div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        <!-- Internet Connection Status-->
        <div class="internet-connection-status" id="internetStatus"></div>
    </div>
@endsection

@section('footer')
    <div class="footer-nav-area" id="footerNav">
        
    </div>
@endsection 
@push('scripts')
    <script src="{{ asset('js/carrinho.js') }}"></script>
@endpush
