@extends('layouts.app')    

@section('title')
    ifome - meus negócios
@endsection  

@section('header')

    <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
        <div class="col-1">
            
        </div>
        @foreach ($negocios as $item)                    
            <div class=" col" style="border-right: solid 1px white;">
                <a href="{{ route('negocios', $item['valor']) }}"><span> {{$item['descrisao']}} </span></a>
            </div>
        @endforeach
       
        <div class="col-1">
            
        </div>
        <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
    </div>
    
    <div class="row header-area-1 testando">
        
        <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
            <span></span><span></span><span></span>
        </div>

        <div class="col-1 logo-wrapper ">
            <a href="{{route('home')}}"><img src="{{asset('img/bg-img/core-img/logo4.png')}}" alt=""></a>
        </div>
        <!-- Search Form-->
        <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
            <form action="" method="">
                <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
        <!-- Navbar Toggler-->
        <div class="col justify-content-between">
            <i class="lni lni-world"></i>
            linguagem
        </div>
        <div class=" col ">
            <i class=" lni lni-user "></i>
            Minha Conta
        </div>
        <div class=" col ">
            <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
            <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
            {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                Cart
            </a>
        </div>
    </div>
@endsection  

@section('content')
<div class="container-fluid">
    
        <div class="row negocios-link">
            <div class="negocios-link-links col">
                <a class="" href="#"><i class="lni lni-map-marker"></i> Localizaçao </a>
            </div>
            @foreach ($links as $item)  
                <!-- Single Flash Sale Card-->
                <div class="links col">
                    <a class="" href="{{$item['url']}}">{{$item['descrisao']}}</a>
                </div>        
            @endforeach          
            <div class="col">
                <a class="" href="{{ route('home') }}">Limpeza</a>
            </div>
        </div>

    <div class="row">
        <div class="col">
            <h2>
                {{$nomeNegocio[0]['descrisao']}} em:
            </h2>
        </div>
    </div>

    <div class="row ">
        @foreach ($arrayDeProdutos as $item)
            <div class="col-md-4 card-negocios">
                <a href="{{ route('produtosDosNegocios', $item['identidade']) }}">
                    <div class="card" style="width: 25rem;">
                        <img class="card-img-top" src="{{asset($item['link'])}}" alt="Card image cap">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-8"> <h5 class="card-title">{{$item['nome']}}</h5></div>
                                <div class="col negocios-horario">{{$item['horario']}}</div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        @endforeach
    </div>
</div>



    
@endsection