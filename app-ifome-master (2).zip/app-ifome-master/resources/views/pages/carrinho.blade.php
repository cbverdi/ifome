@extends('layouts.app')

@section('title')
    ifome - Carrinho de compra
@endsection  


@section('content')

    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2>Carrinho de compras teste</h2>
                <hr>
                
            </div>
            <div class="col-12">
               @if ($cart)
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Produto</th>
                                <th>Loja</th>
                                <th>Preço</th>
                                <th>Quantidade</th>
                                <th>Subtotal</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php 
                                $total= 0;
                            @endphp
                            
                            {{-- {{dd($cart)}} --}}
                            @foreach ($cart as $item)
                                <tr>
                                    <td>{{ $item['id'] }}</td>
                                    <td>{{ $item['nome'] }}</td>
                                    <td>{{ $item['nome_loja'] }}</td>
                                    <td>{{ number_format(($item['preco_venda']), 2, '.',',') }} ECV</td>
                                    <td>{{ $item['quantidade'] }}</td>
                                    @php
                                        $subtotal = $item['preco_venda'] * $item['quantidade'];
                                        $total += $subtotal;
                                    @endphp
                                {{-- <td>{{ number_format(($item['preco_venda'] * $item['quantidade']), 2, ',') }}</td> --}}
                                <td>{{ number_format($subtotal, 2, '.',',') }} ECV</td>
                                    <td>
                                        <a href="{{ route('carrinho.remove', ['id' => $item['id']]) }}" class="btn btn-sm btn-danger">REMOVER</a>
                                    </td>
                                </tr> 
                            @endforeach
                            <tr>
                                <td colspan="5">Total:</td>
                                <td colspan="2">{{ number_format( $total, 2, '.',',') }} ECV</td>
                            </tr>
                        </tbody>
                    </table>
                    <hr>
                    <div class="col-md-12">
                        <a href="" class="btn tbn-lg btn-success float-right">Concluir Compra</a>
                        {{-- <a href="{{route('carrinho.cancel')}}" class="btn tbn-lg btn-danger float-left">Limpar a lista</a> --}}
                    </div>
                @else
                    <div class="alert alert-success">carrinho vazio...</div>
                @endif
            </div>
        </div>
    </div>


    
@endsection