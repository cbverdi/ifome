@extends('layouts.app')


@section('title')
    ifome - configurações
@endsection  

@section('header')
<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-between">
        <!-- Logo Wrapper-->
        <div class="logo-wrapper"><a href="home"><img src="img/bg-img/core-img/logo4.png" alt=""></a></div>
        <!-- Search Form-->
            <div class="top-search-form">
                <form action="" method="">
                    <input class="form-control" type="search" placeholder="Enter your keyword">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
        <!-- Navbar Toggler-->
        <div class="suha-navbar-toggler d-flex flex-wrap" id="suhaNavbarToggler"><span></span><span></span><span></span></div>
    </div>
</div>
 <!-- Sidenav Black Overlay-->
 <div class="sidenav-black-overlay"></div>
 <!-- Side Nav Wrapper-->
 <div class="suha-sidenav-wrapper" id="sidenavWrapper">
 <!-- Sidenav Profile-->
 <div class="sidenav-profile">
     <div class="user-profile"><img src="img/bg-img/avatar/defaultMen.jpg" alt=""></div>
     <div class="user-info">
     <h6 class="user-name mb-0">Nome</h6>
     <p class="available-balance">Saldo: <span>$<span class="counter">523.98</span></span></p>
     </div>
 </div>
 <!-- Sidenav Nav-->
 <ul class="sidenav-nav pl-0">
     <li><a href="{{ route('perfil') }}"><i class="lni lni-user"></i>Meu Perfil</a></li>
     <li><a href="notifications"><i class="lni lni-alarm lni-tada-effect"></i>Notificações<span class="ml-3 badge badge-warning">3</span></a></li>
     <li class="suha-dropdown-menu"><a href="#"><i class="lni lni-cart"></i>Shop Pages</a>
     <ul>
         <li><a href="shop-grid">- Shop Grid</a></li>
         <li><a href="shop-list">- Shop List</a></li>
         <li><a href="single-product">- Product Details</a></li>
         <li><a href="featured-products">- Featured Products</a></li>
         <li><a href="flash-sale">- Flash Sale</a></li>
     </ul>
     </li>
     <li><a href="pages"><i class="lni lni-empty-file"></i>Todas as páginas</a></li>
     <li class="suha-dropdown-menu"><a href="wishlist-grid"><i class="lni lni-heart"></i>Minha Lista de Desejos</a>
     <ul>
         <li><a href="wishlist-grid.html">- Wishlist Grid</a></li>
         <li><a href="wishlist-list.html">- Wishlist List</a></li>
     </ul>
     </li>
     <li><a href="settings.html"><i class="lni lni-cog"></i>Settings</a></li>
     <li><a href="intro.html"><i class="lni lni-power-switch"></i>Sair</a></li>
 </ul>
 <!-- Go Back Button-->
 
 </div>
@endsection  


@section('content')

<div class="page-content-wrapper">
    <div class="container">
      <!-- Cart Wrapper-->
      <div class="cart-wrapper-area py-3">
        <div class="cart-table card mb-3">
          <div class="table-responsive card-body">
            <table class="table mb-0">
              <tbody>
                <tr>
                  <th scope="row"><a class="remove-product" href="#"><i class="lni lni-close"></i></a></th>
                  <td><img src="img/product/11.png" alt=""></td>
                  <td><a href="single-product.html">Ciramic Pot Set<span>$12.10 × 1</span></a></td>
                  <td>
                    <div class="quantity">
                      <input class="qty-text" type="text" value="1">
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row"><a class="remove-product" href="#"><i class="lni lni-close"></i></a></th>
                  <td><img src="img/product/14.png" alt=""></td>
                  <td><a href="single-product.html">Bluetooth Speaker<span>$9.87 × 2</span></a></td>
                  <td>
                    <div class="quantity">
                      <input class="qty-text" type="text" value="2">
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row"><a class="remove-product" href="#"><i class="lni lni-close"></i></a></th>
                  <td><img src="img/product/10.png" alt=""></td>
                  <td><a href="single-product.html">Modern Gray Tops<span>$7 × 1</span></a></td>
                  <td>
                    <div class="quantity">
                      <input class="qty-text" type="text" value="1">
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!-- Coupon Area-->
        <div class="card coupon-card mb-3">
          <div class="card-body">
            <div class="apply-coupon">
              <h6 class="mb-0">Tem um coupom?</h6>
              <p class="mb-2">Insira seu código de cupom aqui &amp; e obtenha descontos incríveis!</p>
              <div class="coupon-form">
                <form action="#">
                  <input class="form-control" type="text" placeholder="SUHA30">
                  <button class="btn btn-primary" type="submit">Aplicar</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- Cart Amount Area-->
        <div class="card cart-amount-area">
          <div class="card-body d-flex align-items-center justify-content-between">
            <h5 class="total-price mb-0">$<span class="counter">38.84</span></h5><a class="btn btn-warning" href="checkout.html">Pagar Agora</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Internet Connection Status-->
  <div class="internet-connection-status" id="internetStatus"></div>
  
@endsection


@section('footer')
<div class="footer-nav-area" id="footerNav">
    <div class="container h-100 px-0">
      <div class="suha-footer-nav h-100">
        <ul class="h-100 d-flex align-items-center justify-content-between pl-0">
          <li class="active"><a href="{{ route('home') }}"><i class="lni lni-home"></i>Home</a></li>
          <li><a href="{{ route('perfil') }}"><i class="lni lni-user"></i>Perfil</a></li>
          <li><a href="{{ route('cart') }}"><i class="lni lni-shopping-basket"></i>cart</a></li>
          <li><a href="pages"><i class="lni lni-heart"></i>Pages</a></li>
          <li><a href="{{ route('settings') }}"><i class="lni lni-cog"></i>Settings</a></li>
        </ul>
      </div>
    </div>
  </div>
@endsection 