@extends('layouts.app')   


@section('title')
    ifome - Seu Carrinho de compra
@endsection  

@section('header')

    <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
        <div class="col-1">
            
        </div>
        @foreach ($negocios as $item)                    
            <div class=" col" style="border-right: solid 1px white;">
                <a href="{{ route('negocios', $item['valor']) }}"><span> {{$item['descrisao']}} </span></a>
                </a>
            </div>
        @endforeach
       
        <div class="col-1">
            
        </div>
        <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
    </div>
    
    <div class="row header-area-1 testando">
        
        <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
            <span></span><span></span><span></span>
        </div>

        <div class="col-1 logo-wrapper ">
            <a href="{{route('home')}}"><img src="img/bg-img/core-img/logo4.png" alt=""></a>
        </div>
        <!-- Search Form-->
        <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
            <form action="" method="">
                <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
        <!-- Navbar Toggler-->
        <div class="col justify-content-between">
            <i class="lni lni-world"></i>
            linguagem
        </div>
        <div class=" col ">
            <i class=" lni lni-user "></i>
            Minha Conta
        </div>
        <div class=" col ">
                <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
            <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
            {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                Cart
            </a>
        </div>
    </div>
@endsection 

@section('content')

    <br>
    <div class="row ">
        <div class="col-8">
            <div class="container-fluid">
                <div class="card product-information">
                    <div class="card-body">
                        <h2>Carrinho de compras</h2>
                        {{-- <div class="select-all-container" clk_trigger="" st_page_id="0oqnggwpgzocaslk17540c30619238edbaf578fce0" ae_page_type="Shopping_Cart_Page" ae_page_area="Overall" ae_button_type="select_all_items" ae_object_type="button" data-aplus-clk="x1_34528fc3" data-spm-anchor-id="a2g0o.cart.0.i37.5b5c3c00MSuXy1"><label class="next-checkbox-wrapper select-all checked focused">
                        <span class="next-checkbox"><span class="next-checkbox-inner"><i class="next-icon next-icon-select next-xs"></i></span><input type="checkbox" aria-checked="true" class="next-checkbox-input" data-spm-anchor-id="a2g0o.cart.0.i725.5b5c3c00MSuXy1"></span><span class="next-checkbox-label"> Selecionar todos</span></label></div> --}}
                    </div>
                </div>
                <hr>
                @if(Cart::count() > 0)
                    @if(Session::has('retorno'))
                    
                    <div class="alert alert-info alert-dismissible fade show" role="alert">{{ Session::get('retorno') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    @endif
                
                    @foreach (Cart::content() as $item)
                        
                        <div class="card card-product-collection">
                            <div class="card-header"> 
                                <label for="store">Loja: {{$item->options['nomeLoja']}} </label><br>
                            </div>
                            <div class="card-body product-field">
                                <div class="row">
                                    <div class="img-product-field col-4 ">
                                        <img class="mb-2" src="{{asset($item->options['img'])}}" alt="">
                                    </div>
                                    <div class="col">
                                        <div class="row justify-content-between">
                                            <div class="col-10">
                                                <h6>Produto: {{$item->name}} </h6>
                                            </div>
                                            <div class="col-2 card-trash">
                                                <h5>
                                                    <a  href="{{route('meucarrinho.remove', $item->rowId )}}"><i class="lni lni-trash" style="color: black"></i></a>
                                                </h5>
                                            </div>
                                        </div> 
                                        <div class="row card-color-text">
                                            Cor:
                                        </div> 
                                        <div class="row card-price-text">
                                            Preço: {{$item->price}} ECV
                                        </div> 
                                        <div class="row ">
                                            <div class="col-10 card-quantity-text">
                                                <form class="cart-form" action="#" method="">
                                                    Quantidade:
                                                    <div class="ml-3 order-plus-minus d-flex align-items-center">
                                                        <div onclick="diminuirQuantidade(this.nextElementSibling, '{{ $item->rowId}}', {{$item->id}})" class="quantity-button-handler">-</div>
                                                        <input class="form-control cart-quantity-input" type="text" step="1" name="qty" value=" {{$item->qty}} ">
                                                        <div onclick="aumentarQuantidade(this.previousElementSibling, '{{ $item->rowId}}', {{$item->id}})"  class="quantity-button-handler">+</div>
                                                    </div>
                                                </form>
                                            </div>
                                            @php
                                            
                                            
                                            @endphp
                                        </div>                        
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="row justify-content-end">
                                        <div class="col">
                                            
                                            <a href="#" class=" btn btn-danger  float-right" type="submit">compre desta loja</a>
                                            
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                            </div>
                        </div>  
                    @endforeach
                    
                @else 
                    <div class="alert alert-danger">carrinho vazio...</div>
                    <hr>
                    <a href="{{ route('home') }}" class=" btn btn-danger float-left"> <i class="fa fa-arrow-left"></i> Voltar aos produtos</a>
                @endif
            </div>
        </div>        
        
        <div class=" col-4">
            <div class="container-fluid">
                
                <div class="card product-resume">
                    <div class="card-header ">
                        <h2> Resumo do pedido </h2>
                    </div>
                    <div class="card-body ">
                        <div class="row">
                            <div class="col">
                                Sub-total 
                            </div>
                            <div class="col">
                            <h6><span id="subTotalCompra"> {{ Cart::subtotal() }}</span> ECV</h6>
                            </div>
                        </div>
                        <div class="row delivery-product">
                            <div class="col">
                               Entrega
                            </div>
                            <div class="col">
                                <h6>0.00ECV</h6>
                            </div>
                        </div>
                        <div class="row">
                            <div class="total-product col">
                                <h6>total</h6>
                            </div>
                            <div class="col">
                                
                                <h5><span id="TotalCompra"> {{ Cart::total() }}</span> ECV</h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <a href="{{ route('home') }}" class="button-total-product btn btn-danger float-left" >Continuar Comprando</a>
                            </div>
                            <div class="col-md-6">
                                <a href="" class="button-total-product btn-danger btn " type="submit">Finalizar a Compra</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </div>        
    </div>

@endsection
@push('scripts')
    <script src="{{ asset('js/carrinho.js') }}"></script>
@endpush