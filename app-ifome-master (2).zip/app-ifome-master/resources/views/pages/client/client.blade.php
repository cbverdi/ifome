@extends('layouts.app')


@section('content')
<h1>pagina de client</h1>
    
@endsection
