@extends('layouts.app')


@section('title')
    ifome - Perfil
@endsection  

@section('header')
<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-between">
        <!-- Logo Wrapper-->
        <div class="logo-wrapper"><a href="home"><img src="img/bg-img/core-img/logo4.png" alt=""></a></div>
        <!-- Search Form-->
            <div class="top-search-form">
                <form action="" method="">
                    <input class="form-control" type="search" placeholder="Enter your keyword">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
        <!-- Navbar Toggler-->
        <div class="suha-navbar-toggler d-flex flex-wrap" id="suhaNavbarToggler"><span></span><span></span><span></span></div>
    </div>
</div>
 <!-- Sidenav Black Overlay-->
 <div class="sidenav-black-overlay"></div>
 <!-- Side Nav Wrapper-->
 <div class="suha-sidenav-wrapper" id="sidenavWrapper">
 <!-- Sidenav Profile-->
 <div class="sidenav-profile">
     <div class="user-profile"><img src="img/bg-img/avatar/defaultMen.jpg" alt=""></div>
     <div class="user-info">
     <h6 class="user-name mb-0">Nome</h6>
     <p class="available-balance">Saldo: <span>$<span class="counter">523.98</span></span></p>
     </div>
 </div>
 <!-- Sidenav Nav-->
 <ul class="sidenav-nav pl-0">
     <li><a href="profile"><i class="lni lni-user"></i>Meu Perfil</a></li>
     <li><a href="notifications"><i class="lni lni-alarm lni-tada-effect"></i>Notificações<span class="ml-3 badge badge-warning">3</span></a></li>
     <li class="suha-dropdown-menu"><a href="#"><i class="lni lni-cart"></i>Shop Pages</a>
     <ul>
         <li><a href="shop-grid">- Shop Grid</a></li>
         <li><a href="shop-list">- Shop List</a></li>
         <li><a href="single-product">- Product Details</a></li>
         <li><a href="featured-products">- Featured Products</a></li>
         <li><a href="flash-sale">- Flash Sale</a></li>
     </ul>
     </li>
     <li><a href="pages"><i class="lni lni-empty-file"></i>Todas as páginas</a></li>
     <li class="suha-dropdown-menu"><a href="wishlist-grid"><i class="lni lni-heart"></i>Minha Lista de Desejos</a>
     <ul>
         <li><a href="wishlist-grid.html">- Wishlist Grid</a></li>
         <li><a href="wishlist-list.html">- Wishlist List</a></li>
     </ul>
     </li>
     <li><a href="settings.html"><i class="lni lni-cog"></i>Settings</a></li>
     <li><a href="intro.html"><i class="lni lni-power-switch"></i>Sair</a></li>
 </ul>
 <!-- Go Back Button-->
 
 </div>
@endsection  


@section('content')
<div class="page-content-wrapper">
    <div class="container">
      <!-- Profile Wrapper-->
      <div class="profile-wrapper-area py-3">
        <!-- User Information-->
        <div class="card user-info-card">
          <div class="card-body p-4 d-flex align-items-center">
            <div class="user-profile mr-3"><img src="img/bg-img/avatar/defaultMen.jpg" alt=""></div>
            <div class="user-info">
              <p class="mb-0 text-white">(.......)</p>
              <h5 class="mb-0">Nome do Usuário</h5>
            </div>
          </div>
        </div>
        <!-- User Meta Data-->
        <div class="card user-data-card">
          <div class="card-body">
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-user"></i><span>Username</span></div>
              <div class="data-content">Jaquinta.keiru</div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-user"></i><span>Full Name</span></div>
              <div class="data-content">Jaquinta keiru</div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-phone"></i><span>Phone</span></div>
              <div class="data-content">+880 000 111 222</div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-envelope"></i><span>Email Address</span></div>
              <div class="data-content">Jack@exemplo.com                                </div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-map-marker"></i><span>Shipping</span></div>
              <div class="data-content">28/C Rua de Lisboa, Varzea</div>
            </div>
            <div class="single-profile-data d-flex align-items-center justify-content-between">
              <div class="title d-flex align-items-center"><i class="lni lni-star"></i><span>My Order</span></div>
              <div class="data-content"><a class="btn btn-danger btn-sm" href="my-order">Ver</a></div>
            </div>
          </div>
        </div>
        <!-- Edit Profile-->
        <div class="edit-profile-btn mt-3"><a class="btn btn-info w-100" href="edit-profile"><i class="lni lni-pencil mr-2"></i>Editar Perfil</a></div>
      </div>
    </div>
  </div>
  <!-- Internet Connection Status-->
  <div class="internet-connection-status" id="internetStatus"></div>
  
@endsection


@section('footer')
<div class="footer-nav-area" id="footerNav">
    <div class="container h-100 px-0">
      <div class="suha-footer-nav h-100">
        <ul class="h-100 d-flex align-items-center justify-content-between pl-0">
          <li class="active"><a href="home"><i class="lni lni-home"></i>Home</a></li>
          <li><a href="{{ route('perfil') }}"><i class="lni lni-user"></i>Perfil</a></li>
          <li><a href="cart"><i class="lni lni-shopping-basket"></i>cart</a></li>
          <li><a href="pages"><i class="lni lni-heart"></i>Pages</a></li>
          <li><a href="settings"><i class="lni lni-cog"></i>Settings</a></li>
        </ul>
      </div>
    </div>
  </div>
@endsection 