@extends('layouts.app')   

@section('title')
    ifome - detalhes do produto
@endsection  

@section('header')


        <div class="container-fluid">
             <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
                <div class="col-1">
                    
                </div>
                @foreach ($negocios as $item)                    
                    <div class=" col" style="border-right: solid 1px white;">
                        <a href="{{ route('negocios', $item['valor']) }}"><span> {{$item['descrisao']}} </span></a>
                    </div>
                @endforeach
                <div class="col-1">
                    
                </div>
                <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
             </div>
            <div class="row  header-area-1 testando">
                <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
                    <span></span><span></span><span></span>
                </div>
        
                <div class="col-1 logo-wrapper ">
                    <a href="{{route('home')}}"><img src="{{ asset('img/bg-img/core-img/logo4.png') }}" alt=""></a>
                </div>
                <!-- Search Form-->
                <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
                    <form action="" method="">
                        <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
                <!-- Navbar Toggler-->
                <div class="col justify-content-between ">
                    <a href="#"><i class="lni lni-world"></i> Linguagem</a>
                </div>
                <div class="col">
                    <a href="#"><i class="lni lni-user "></i> Minha Conta</a>
                </div>
                <div class="col">
                <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
                    <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
                    {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                        Cart
                    </a>
                    
                </div>
            </div>
                

            <div class="row products-link">
                <div class="links col">
                    <a class="" href="#"><i class="lni lni-map-marker"></i> Localizaçao </a>
                </div>
                @foreach ($links as $item)  
                    <!-- Single Flash Sale Card-->
                    <div class="links col">
                        <a class="" href="{{$item['url']}}">{{$item['descrisao']}}</a>
                    </div>        
                @endforeach          
                <div class="col">
                    <a class="" href="{{ route('home') }}">Limpeza</a>
                </div>
                <div class="col">
                    <a class="" style="color: #991010" href="#"><i class="lni lni-postcard" style="font-size: 22px"></i> Associar Cartao</a>
                </div>
            </div>
        </div>

  @endsection




@section('content')

<div class="container-fluid"> 
    <div class="row info-path">
        
        Path/Path/Path
    </div>
    <div class="row info-imagem">
       
        <div class="img-scroll col-1">
            @php  $count = 0; @endphp
      
            @foreach ($retornaArra[0]['imagem'] as $item)
                <div class="image-view-scroll"><img class="mb-2" src="{{ asset($item) }}" alt=""> </div>
                
                @php  $count++; @endphp
            @endforeach
        </div>
        <div class="col-4 product-image-view">
            <img class="mb-2" src="{{ asset($retornaArra[0]['img']) }}" alt="">
        </div>
        <div class="col-7">
            <div class="row product-name justify-content-between">
                <div class="col-8">
                    <h2>{{$retornaArra[0]['nome']}}</h2>
                </div>
                <div class="col-2">
                    <img class="mb-2" src="{{ asset('img/bg-img/share-icon.png') }}" alt="">
                </div>
            </div>

            <div class="row product-info">
                <h6> {{$retornaArra[0]['descricao']}}</h6>
            </div>
            <div class="row product-price">
                <h5>preço:{{ number_format(($retornaArra[0]['preco_venda']), 2, '.',',') }} ECV </h5>
            </div>
            <div class="row product-length">
                <h6>tamanho: {{$retornaArra[0]['tamanho']}}</h6>
            </div>
            <div class="row product-color">
                <h6>cor:</h6>
                @php  $count = 0; @endphp
                @foreach ($retornaArra[0]['cor'] as $item)
                    <div class="image-view-color"><img class="mb-2" src="{{ asset($item) }}" alt=""> </div>
                    @php  $count++; @endphp
                @endforeach
            </div>
            <hr>
            <form class="addCarrinhoForm" data-idproduto="{{$retornaArra[0]['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                @csrf
                <input type="hidden" name="cod_produto" value="{{$retornaArra[0]['cod_produto']}}">
                <input type="hidden" name="nome" value="{{$retornaArra[0]['nome']}}">
                <input type="hidden" name="preco_venda" value="{{$retornaArra[0]['preco_venda']}}">
                <input type="hidden" name="nome_loja" value="{{$retornaArra[0]['nome_loja']}}">
                <input type="hidden" name="img" value="{{$retornaArra[0]['img']}}">
                <input type="hidden" name="peso" value="{{$retornaArra[0]['peso']}}">
                <input type="hidden" name="quantidade" value="1">
                
                <div class="row product-button">
                    <button class="btn btn-danger ml-3" type="submit">Adicionar</button>
                </div>
            </form>
            
        </div>
    </div>

    <div class="related-products row">
        <div class="section-heading d-flex align-items-center justify-content-between">
            <h5 class="ml-1">Produtos relacionados</h5>
        </div>
        <div class="col-1 arrow">
            <h1>
                <i class="lni lni-chevron-left"></i>
            </h1>
        </div>
        <div class="col-10">
            <!-- Flash Sale Slide-->
            <div class="flash-sale-wrapper">
                <!-- Flash Sale Slide-->
                <div class="flash-sale-slide owl-carousel">
                    
                    @foreach ($detalhes as $item)  
                        <!-- Single Flash Sale Card-->
                        <div class="card flash-sale-card">
                        <div class="card-body"><a href="{{ route('detalhedoproduto', $item['cod_produto']) }}"><img src="{{ asset($item['img']) }}" alt=""><span class="product-title">{{ $item['nome'] }}</span>
                            <p class="sale-price">{{$item['preco_venda']}}<span class="real-price">{{$item['preco_real']}}</span></p><span class="progress-title">57% Sold Out</span>
                            <!-- Progress Bar-->
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: 57%" aria-valuenow="57" aria-valuemin="0" aria-valuemax="100"></div>
                            </div></a></div>
                        </div>
                    @endforeach
                   
                </div>
                
            </div>
        </div>

        <div class="col-1 arrow">
            <h1>
                <i class="lni lni-chevron-right"></i>
            </h1>
            
        </div>
    </div>

  
</div>

@endsection
@push('scripts')
    <script src="{{ asset('js/carrinho.js') }}"></script>
@endpush