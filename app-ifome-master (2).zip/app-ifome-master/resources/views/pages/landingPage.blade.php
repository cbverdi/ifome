@extends('layouts.app')   


@section('title')
    ifome - entrega e mais. você pede nós Entregamos
@endsection

@section('content')
    <div class="container-fluid landing-page">
        
        <div class="row landing-searh justify-content-between">
            <div class="col-4">
                <i class="lni lni-search-alt" style="font-size: 35px"></i>
                O que você precisa?
            </div>
            <div class="col-4">
                
                <button class="btn  ml-3 btn-lg button-landing-register"  type="submit" style="border-radius: 2rem"><a class="ml-1" href="{{ route('registo') }}" >Registar</a></button>
                <button class="btn  ml-3 btn-lg button-landing-login" type="submit" style="border-radius: 2rem"><a class="ml-1" style="color: black" href="{{ route('login') }}">Login</a></button>
            </div>
        </div>
        
        
    </div>
    <div class="row landing-logo-ifome justify-content-center">
        <div class="col-2">
            <img src="img/bg-img/icon/logo-ifome.png" class="img-fluid" alt="Responsive image">
        </div>

    </div>
    <div class="row landing-island-ifome justify-content-center">
        <div class="col-10">
            Qualquer coisa em Santiago
           <!-- <div class="Santiago">
                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Santiago
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                  <button class="dropdown-item" type="button">Maio </button>
                  <button class="dropdown-item" type="button">São Vicente</button>
                  <button class="dropdown-item" type="button">Brava</button>
                </div>
              </div>-->
        </div>
    </div>
    <div class="row landing-island-ifome justify-content-center">
        <div class="col-10">
            Entregue em minutos 
        </div>
    </div>
    <div class="row landing-categories-ifome justify-content-center" >
        
        @foreach ($negocios as $item)
            <div class="col-2 category-bubble ">
                <a href="{{ route('negocios', $item['valor']) }}"> <img src="{{$item['img']}}" class="img-fluid" style="height: 70px; margin-top: 5px" alt=""></a>
                {{$item['descrisao']}}
            </div>
        @endforeach
        
        
    </div>
    <div class="row landing-categories-ifome justify-content-center" >
        
        <div class="col-2 category-bubble ">
            <img src="img/bg-img/icon/img3.png" class="img-fluid" style="height: 70px; margin-top: 5px" alt="Responsive image">
            SuperMercados
        </div>
        <div class="col-2 category-bubble ">
            <img src="img/bg-img/icon/img2.png" class="img-fluid" style="height: 70px; margin-top: 5px" alt="Responsive image">
            Cafés & Lanches
        </div>
        
    </div>

@endsection
