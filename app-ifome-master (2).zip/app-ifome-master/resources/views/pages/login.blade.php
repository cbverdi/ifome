@extends('layouts.app')   


@section('title')
    ifome - faça login da sua conta
@endsection 


@section('content')

<div class="login-wrapper d-flex align-items-center justify-content-center text-center">
    <!-- Background Shape-->
    
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12 col-sm-9 col-md-7 col-lg-6 col-xl-5">
          
          <img src="uploads/ifome.png" class="img-fluid" alt="Responsive image">
          <!-- Register Form-->
          <div class="register-form mt-3 px-4">
            <form method="">
              <div class="form-group text-left mb-3"><span>Telefone</span>
                <label for="name"><i class="lni lni-phone"></i></label>
                <input class="form-control" id="name" type="text" placeholder="digite o número do seu telemovel">
              </div>
              <div class="form-group text-left mb-4"><span>Password</span>
                <label for="password"><i class="lni lni-lock"></i></label>
                <input class="form-control" id="password" type="password" placeholder="**************">
              </div>
              <button class="button btn btn-danger btn-lg w-100" type="submit">Login</button>
            </form>
          </div>
          <div class="login-meta-data">
            <p class="mb-0" style="color: grey">Não tem uma conta?<a class="ml-1" href="{{ route('registo') }}" >Registe-se aqui</a></p>
          </div>
           <!-- View As Guest-->
           <div class="view-as-guest mt-3"><a class="ml-1 mb-5 " style="color: #991010" href="{{ route('home') }}">Entrar como convidado</a></div>
          
        </div>
      
      </div>
    </div>
  </div>
    
@endsection
