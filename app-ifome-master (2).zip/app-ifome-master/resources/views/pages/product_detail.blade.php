@extends('layouts.app')    

@section('title')
    ifome - Detalhe do produto
@endsection  

@section('header')
    <div class="header-area" id="headerArea">
        <div class="container h-100 d-flex align-items-center justify-content-between">
            <!-- Logo Wrapper-->
            <div class="logo-wrapper"><a href="home"><img src="img/bg-img/core-img/logo4.png" alt=""></a></div>
            <!-- Page Title-->
            <div class="page-heading">
                <h6 class="mb-0">Detalhe do Produto</h6>
            </div>
            <!-- Navbar Toggler-->
            <div class="suha-navbar-toggler d-flex flex-wrap" id="suhaNavbarToggler"><span></span><span></span><span></span></div>
        </div>
    </div>
@endsection  

@section('content')




<div class="page-content-wrapper">
    <!-- Product Slides-->
    <div class="product-slides owl-carousel">
      
      @php  $count = 0; @endphp
      
      @foreach ($produtos[0]['imagem'] as $item)
      
         <div class="single-product-slide" style="background-image: url('{{$item}}')"></div> 
         @php  $count++; @endphp
      @endforeach

    </div>
    
    <div class="product-description pb-3">
      <!-- Product Title & Meta Data-->
      <div class="product-title-meta-data bg-white mb-3 py-3">
        <div class="container d-flex justify-content-between">
          <div class="p-title-price">
            <h6 class="mb-1">{{$produtos[0]['nome']}}</h6>
            <p class="sale-price mb-0">{{$produtos[0]['preco']}}<span>$81</span></p>
          </div>
          <div class="p-wishlist-share"><a href="wishlist-grid.html"><i class="lni lni-heart"></i></a></div>
        </div>
        
        <!-- Ratings-->
        <div class="product-ratings">
          <div class="container d-flex align-items-center justify-content-between">
            <div class="ratings"><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><span class="pl-1">{{$produtos[0]['classificacao']}}</span></div>
            <div class="total-result-of-ratings"><span>5.0</span><span>Very Good</span></div>
           
          </div>
        </div>
      </div>
      <!-- Flash Sale Panel-->
      <div class="flash-sale-panel bg-white mb-3 py-3">
        <div class="container">
          <!-- Sales Offer Content-->
          <div class="sales-offer-content d-flex align-items-end justify-content-between">
            <!-- Sales End-->
            <div class="sales-end">
              <p class="mb-1 font-weight-bold"><i class="lni lni-bolt"></i>Venda termina em</p>
              <!-- Please use event time this format: YYYY/MM/DD hh:mm:ss-->
              <ul class="sales-end-timer pl-0 d-flex align-items-center" data-countdown="2021/01/01 14:21:37">
                <li><span class="days">0</span>d</li>
                <li><span class="hours">0</span>h</li>
                <li><span class="minutes">0</span>m</li>
                <li><span class="seconds">0</span>s</li>
              </ul>
            </div>
            <!-- Sales Volume-->
            <div class="sales-volume text-right">
              <p class="mb-1 font-weight-bold">82% Esgotado</p>
              <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-warning" role="progressbar" style="width: 82%;" aria-valuenow="82" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Selection Panel-->
      <div class="selection-panel bg-white mb-3 py-3">
        <div class="container d-flex align-items-center justify-content-between">
          <!-- Choose Color-->
          <div class="choose-color-wrapper">
            <p class="mb-1 font-weight-bold">Cor</p>
            <div class="choose-color-radio d-flex align-items-center">
              <!-- Single Radio Input-->
              <div class="form-check mb-0">
                <input class="form-check-input blue" id="colorRadio1" type="radio" name="colorRadio" checked>
                <label class="form-check-label" for="colorRadio1"></label>
              </div>
              <!-- Single Radio Input-->
              <div class="form-check mb-0">
                <input class="form-check-input yellow" id="colorRadio2" type="radio" name="colorRadio">
                <label class="form-check-label" for="colorRadio2"></label>
              </div>
              <!-- Single Radio Input-->
              <div class="form-check mb-0">
                <input class="form-check-input green" id="colorRadio3" type="radio" name="colorRadio">
                <label class="form-check-label" for="colorRadio3"></label>
              </div>
              <!-- Single Radio Input-->
              <div class="form-check mb-0">
                <input class="form-check-input purple" id="colorRadio4" type="radio" name="colorRadio">
                <label class="form-check-label" for="colorRadio4"></label>
              </div>
            </div>
          </div>
          <!-- Choose Size-->
          <div class="choose-size-wrapper text-right">
            <p class="mb-1 font-weight-bold">Tamanho</p>
            <div class="choose-size-radio d-flex align-items-center">
              <!-- Single Radio Input-->
              <div class="form-check mb-0 mr-2">
                <input class="form-check-input" id="sizeRadio1" type="radio" name="sizeRadio">
                <label class="form-check-label" for="sizeRadio1">S</label>
              </div>
              <!-- Single Radio Input-->
              <div class="form-check mb-0 mr-2">
                <input class="form-check-input" id="sizeRadio2" type="radio" name="sizeRadio" checked>
                <label class="form-check-label" for="sizeRadio2">M</label>
              </div>
              <!-- Single Radio Input-->
              <div class="form-check mb-0">
                <input class="form-check-input" id="sizeRadio3" type="radio" name="sizeRadio">
                <label class="form-check-label" for="sizeRadio3">L</label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Add To Cart-->
      <div class="cart-form-wrapper bg-white mb-3 py-3">
        <div class="container">
          <form class="cart-form" action="#" method="">
            <div class="order-plus-minus d-flex align-items-center">
              <div class="quantity-button-handler">-</div>
              <input class="form-control cart-quantity-input" type="text" step="1" name="quantity" value="3">
              <div class="quantity-button-handler">+</div>
            </div>
            <button class="btn btn-danger ml-3" type="submit">Adicionar ao carrinho</button>
          </form>
        </div>
      </div>
      <!-- Product Specification-->
      <div class="p-specification bg-white mb-3 py-3">
        <div class="container">
          <h6>especificações</h6>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, eum? Id, culpa? At officia quisquam laudantium nisi mollitia nesciunt, qui porro asperiores cum voluptates placeat similique recusandae in facere quos vitae?</p>
          <ul class="mb-3 pl-3">
            <li><i class="lni lni-checkmark-circle"> </i> 100% Good Reviews</li>
            <li><i class="lni lni-checkmark-circle"> </i> 7 Days Returns</li>
            <li> <i class="lni lni-checkmark-circle"> </i> Warranty not Aplicable</li>
            <li> <i class="lni lni-checkmark-circle"> </i> 100% Brand New Product</li>
          </ul>
          <p class="mb-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, eum? Id, culpa? At officia quisquam laudantium nisi mollitia nesciunt, qui porro asperiores cum voluptates placeat similique recusandae in facere quos vitae?</p>
        </div>
      </div>
      <!-- Rating & Review Wrapper-->
      <div class="rating-and-review-wrapper bg-white py-3 mb-3">
        <div class="container">
          <h6>Avaliações &amp; comentários</h6>
          <div class="rating-review-content">
            <ul class="pl-0">
              <li class="single-user-review d-flex">
                <div class="user-thumbnail"><img src="img/bg-img/7.jpg" alt=""></div>
                <div class="rating-comment">
                  <div class="rating"><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i></div>
                  <p class="comment mb-0">Very good product. It's just amazing!</p><span class="name-date">Designing World 12 Dec 2020</span>
                </div>
              </li>
              <li class="single-user-review d-flex">
                <div class="user-thumbnail"><img src="img/bg-img/8.jpg" alt=""></div>
                <div class="rating-comment">
                  <div class="rating"><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i></div>
                  <p class="comment mb-0">WOW excellent product. Love it.</p><span class="name-date">Designing World 8 Dec 2020</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- Ratings Submit Form-->
      <div class="ratings-submit-form bg-white py-3">
        <div class="container">
          <h6>Envie uma avaliação</h6>
          <form action="#" method="">
            <div class="stars mb-3">
              <input class="star-1" type="radio" name="star" id="star1">
              <label class="star-1" for="star1"></label>
              <input class="star-2" type="radio" name="star" id="star2">
              <label class="star-2" for="star2"></label>
              <input class="star-3" type="radio" name="star" id="star3">
              <label class="star-3" for="star3"></label>
              <input class="star-4" type="radio" name="star" id="star4">
              <label class="star-4" for="star4"></label>
              <input class="star-5" type="radio" name="star" id="star5">
              <label class="star-5" for="star5"></label><span></span>
            </div>
            <textarea class="form-control mb-3" id="comments" name="comment" cols="30" rows="10" data-max-length="200" placeholder="escreva sua avaliação..."></textarea>
            <button class="btn btn-sm btn-primary" type="submit">Salvar avaliação</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Internet Connection Status-->
  <div class="internet-connection-status" id="internetStatus"></div>
    
@endsection


@section('footer')
    <div class="footer-nav-area" id="footerNav">
      <div class="container h-100 px-0">
        <div class="suha-footer-nav h-100">
          <ul class="h-100 d-flex align-items-center justify-content-between pl-0">
            <li class="active"><a href="{{ route('home') }}"><i class="lni lni-home"></i>Home</a></li>
            <li><a href="{{ route('perfil') }}"><i class="lni lni-user"></i>Perfil</a></li>
            <li><a href="{{ route('cart') }}"><i class="lni lni-shopping-basket"></i>cart</a></li>
            <li><a href="pages"><i class="lni lni-heart"></i>Pages</a></li>
            <li><a href="{{ route('settings') }}"><i class="lni lni-cog"></i>Settings</a></li>
          </ul>
        </div>
      </div>
    </div>
@endsection 
