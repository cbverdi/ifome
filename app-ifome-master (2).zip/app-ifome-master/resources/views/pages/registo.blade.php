@extends('layouts.app')   


@section('content')
<h1>de registo do cliente</h1>
    
@endsection
