@extends('layouts.app')

@section('teste3')

<h1>Página de LOJAS</h1>
    
@endsection