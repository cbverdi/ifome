@extends('layouts.app')    

@section('title')
    ifome - Produtos
@endsection  

@section('header')

    <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
        <div class="col-1">
            
        </div>
        @foreach ($negocios as $item)                    
            <div class=" col" style="border-right: solid 1px white;">
                <a href="{{ route('negocios', $item['valor']) }}"><span> {{$item['descrisao']}} </span></a>
            </div>
        @endforeach
       
        <div class="col-1">
            
        </div>
        <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
    </div>
    
    <div class="row header-area-1 testando">
        
        <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
            <span></span><span></span><span></span>
        </div>

        <div class="col-1 logo-wrapper ">
            <a href="{{route('home')}}"><img src="{{asset('img/bg-img/core-img/logo4.png')}}" alt=""></a>
        </div>
        <!-- Search Form-->
        <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
            <form action="" method="">
                <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
        <!-- Navbar Toggler-->
        <div class="col justify-content-between">
            <i class="lni lni-world"></i>
            linguagem
        </div>
        <div class=" col ">
            <i class=" lni lni-user "></i>
            Minha Conta
        </div>
        <div class=" col ">
            <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
            <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
            {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                Cart
            </a>
        </div>
    </div>
@endsection  

@section('content')
    <div class="container">
        
        
        <!-- PWA Install Alert-->
        
        <div class="page-content-wrapper">
        <!-- Hero Slides-->
        <div class="hero-slides owl-carousel">

            
        @foreach ($imagem as $item)
            <div class="single-hero-slide" style="background-image: url({{asset($item)}})">
                <div class="slide-content h-100 d-flex align-items-center">
                    <div class="container">
                        <h4 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-wow-duration="1000ms">Nome Produto</h4>
                        <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-wow-duration="1000ms">detalhe, preço</p><a class="btn btn-primary btn-sm" href="#" data-animation="fadeInUp" data-delay="800ms" data-wow-duration="1000ms">compre agora</a>
                    </div>
                </div>
            </div>
        @endforeach

         
        </div>
        
        
        <!-- Top Produtos por categorias COMIDAS-->
        <div class="top-products-area clearfix py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Entradas</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">

                    @foreach ($arrayDeProdutos2 as $produto)
                        <div class="col-6 col-md-6 col-lg-6">
                            <div class="card top-product-card">
                                <div class="card-body"><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"></a><a class="product-title d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}">{{$produto['nome']}}</a>
                                    <div class="product-rating">{{$produto['descricao']}}</div>
                                    <p class="sale-price">{{$produto['preco_real']}}.00ECV</p>
                                    <form class="addCarrinhoForm" data-idproduto="{{$produto['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                                        @csrf
                                        <input type="hidden" name="cod_produto" value="{{$produto['cod_produto']}}">
                                        <input type="hidden" name="nome"value="{{$produto['nome']}}">
                                        <input type="hidden" name="nome_loja"value="{{$produto['nome_loja']}}">
                                        <input type="hidden" name="preco_venda"value="{{$produto['preco_venda']}}">
                                        <input type="hidden" name="img"value="{{$produto['img']}}">
                                        <input type="hidden" name="peso"value="{{$produto['peso']}}">
                                        <input type="hidden" name="quantidade" value="1">
                                        <button class="btn btn-success btn-sm"><i class="lni lni-plus"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Top Produtos por categorias SOBREMESAS-->
        <div class="top-products-area clearfix py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Sobremesas</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">

                    @foreach ($arrayDeProdutos1 as $produto)
                        <div class="col-6 col-md-6 col-lg-6">
                            <div class="card top-product-card">
                                <div class="card-body"><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"></a><a class="product-title d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}">{{$produto['nome']}}</a>
                                    <div class="product-rating">{{$produto['descricao']}}</div>
                                    <p class="sale-price">{{$produto['preco_real']}}.00ECV</p>
                                    <form class="addCarrinhoForm" data-idproduto="{{$produto['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                                        @csrf
                                        <input type="hidden" name="cod_produto" value="{{$produto['cod_produto']}}">
                                        <input type="hidden" name="nome"value="{{$produto['nome']}}">
                                        <input type="hidden" name="nome_loja"value="{{$produto['nome_loja']}}">
                                        <input type="hidden" name="preco_venda"value="{{$produto['preco_venda']}}">
                                        <input type="hidden" name="img"value="{{$produto['img']}}">
                                        <input type="hidden" name="peso"value="{{$produto['peso']}}">
                                        <input type="hidden" name="quantidade" value="1">
                                        <button class="btn btn-success btn-sm"><i class="lni lni-plus"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        
        <!-- Top Produtos por categorias BEBIDAS-->
        <div class="top-products-area clearfix py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Bebidas</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">

                    @foreach ($arrayDeProdutos3 as $produto)
                        <div class="col-6 col-md-6 col-lg-6">
                            <div class="card top-product-card">
                                <div class="card-body"><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"></a><a class="product-title d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}">{{$produto['nome']}}</a>
                                    <div class="product-rating">{{$produto['descricao']}}</div>
                                    <p class="sale-price">{{$produto['preco_real']}}.00ECV</p>
                                    <form class="addCarrinhoForm" data-idproduto="{{$produto['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                                        @csrf
                                        <input type="hidden" name="cod_produto" value="{{$produto['cod_produto']}}">
                                        <input type="hidden" name="nome"value="{{$produto['nome']}}">
                                        <input type="hidden" name="nome_loja"value="{{$produto['nome_loja']}}">
                                        <input type="hidden" name="preco_venda"value="{{$produto['preco_venda']}}">
                                        <input type="hidden" name="img"value="{{$produto['img']}}">
                                        <input type="hidden" name="peso"value="{{$produto['peso']}}">
                                        <input type="hidden" name="quantidade" value="1">
                                        <button class="btn btn-success btn-sm"><i class="lni lni-plus"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Top Produtos por categorias PIZZAS-->
        <div class="top-products-area clearfix py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Pizzas</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">

                    @foreach ($arrayDeProdutos4 as $produto)
                        <div class="col-6 col-md-6 col-lg-6">
                            <div class="card top-product-card">
                                <div class="card-body"><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"></a><a class="product-title d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}">{{$produto['nome']}}</a>
                                    <div class="product-rating">{{$produto['descricao']}}</div>
                                    <p class="sale-price">{{$produto['preco_real']}}.00ECV</p>
                                    <form class="addCarrinhoForm" data-idproduto="{{$produto['cod_produto']}}" action="{{route('meucarrinho.add')}}" method="post">
                                        @csrf
                                        <input type="hidden" name="cod_produto" value="{{$produto['cod_produto']}}">
                                        <input type="hidden" name="nome"value="{{$produto['nome']}}">
                                        <input type="hidden" name="nome_loja"value="{{$produto['nome_loja']}}">
                                        <input type="hidden" name="preco_venda"value="{{$produto['preco_venda']}}">
                                        <input type="hidden" name="img"value="{{$produto['img']}}">
                                        <input type="hidden" name="peso"value="{{$produto['peso']}}">
                                        <input type="hidden" name="quantidade" value="1">
                                        <button class="btn btn-success btn-sm"><i class="lni lni-plus"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        <!-- Night Mode View Card-->
        <div class="night-mode-view-card pb-3">
            <div class="container">
            <div class="card settings-card">
                <div class="card-body">
                <div class="single-settings d-flex align-items-center justify-content-between">
                    <div class="title"><i class="lni lni-night"></i><span>Modo Noturno</span></div>
                    <div class="data-content">
                    <div class="toggle-button-cover">
                        <div class="button r">
                        <input class="checkbox" id="darkSwitch" type="checkbox">
                        <div class="knobs"></div>
                        <div class="layer"></div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        <!-- Internet Connection Status-->
        <div class="internet-connection-status" id="internetStatus"></div>
    </div>
@endsection

@section('footer')
    <div class="footer-nav-area" id="footerNav">
        
    </div>
@endsection 
@push('scripts')
    <script src="{{ asset('js/carrinho.js') }}"></script>
@endpush
