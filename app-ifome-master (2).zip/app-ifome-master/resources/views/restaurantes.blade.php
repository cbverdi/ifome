@extends('layouts.app')    

@section('title')
    ifome - restaurantes
@endsection  

@section('header')

    <div class="row header-mylist justify-content-between" style="border-block-end: solid 1px white;">
        <div class="col-1">
            
        </div>
        @foreach ($negocios as $item)                    
            <div class=" col" style="border-right: solid 1px white;">
                <a href="{{$item['link']}} "><span> {{$item['descrisao']}} </span></a>
            </div>
        @endforeach
       
        <div class="col-1">
            
        </div>
        <div class="col" style="color: white"><a class="" href="#"><i class="lni lni-heart-filled"></i> As minhas listas</a></div>
    </div>
    
    <div class="row header-area-1 testando">
        
        <div class=" suha-navbar-toggler d-flex flex-wrap col-1">
            <span></span><span></span><span></span>
        </div>

        <div class="col-1 logo-wrapper ">
            <a href="home"><img src="img/bg-img/core-img/logo4.png" alt=""></a>
        </div>
        <!-- Search Form-->
        <div class="top-search-form  col-6 col-lg-6 col-lg-6 col-xl-6 col-md-6 col-sm-6">
            <form action="" method="">
                <input class="form-control" type="search" placeholder="pesquiza seus produtos">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
        <!-- Navbar Toggler-->
        <div class="col justify-content-between">
            <i class="lni lni-world"></i>
            linguagem
        </div>
        <div class=" col ">
            <i class=" lni lni-user "></i>
            Minha Conta
        </div>
        <div class=" col ">
            <span id="contadorCarrinho"> {{ Cart::instance('default')->count() }}</span>
            <a href="{{ route('meucarrinho.index') }}"><i class="lni lni-cart lni-lg"></i> 
            {{-- <a href="{{ route('carrinho.index') }}"><i class="fa fa-shopping-cart "></i>  --}}
                Cart
            </a>
        </div>
    </div>
@endsection  

@section('content')
    <div class="container">
        
        
        <!-- PWA Install Alert-->
        
        <div class="page-content-wrapper">
        <!-- Hero Slides-->
        <div class="hero-slides owl-carousel">

            
        @foreach ($imagem as $item)
            <div class="single-hero-slide" style="background-image: url({{$item}})">
                <div class="slide-content h-100 d-flex align-items-center">
                    <div class="container">
                        <h4 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-wow-duration="1000ms">Nome Produto</h4>
                        <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-wow-duration="1000ms">detalhe, preço</p><a class="btn btn-primary btn-sm" href="#" data-animation="fadeInUp" data-delay="800ms" data-wow-duration="1000ms">compre agora</a>
                    </div>
                </div>
            </div>
        @endforeach

         
        </div>
        <!-- Product Catagories-->
        <div class="product-catagories-wrapper py-3">
            <div class="container">
                <div class="section-heading">
                    <h6 class="ml-1">
                        <br>
                    </h6>
                </div>
                <div class="product-catagory-wrap">
                    <div class="row g-3">
                        
                       @foreach ($entidades as $item)                    
                            <div class="col-4">
                                <div class="card catagory-card">
                                <div class="card-body"><a href="{{$item['link']}} "><i class="lni lni-restaurant"></i><span> {{$item['descrisao']}} </span></a></div>
                                </div>
                            </div>
                        @endforeach
                        
                    </div>
                </div>
            </div>
        </div> 
        
        
        <!-- Top Products-->
        <div class="top-products-area clearfix py-3">
            <div class="container-fluid">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="ml-1">Destaques em alta</h6><a class="btn btn-danger btn-sm" href="shop-grid">Ver todos</a>
                </div>
                <div class="row g-3">
                     <!-- Single Weekly Product Card-->
                @foreach ($produtosPopulares as $produto)
                <div class="col-12 col-md-6">
                    <div class="card weekly-product-card">
                        <div class="card-body d-flex align-items-center">
                            <div class="product-thumbnail-side"><span class="badge badge-success">Sale</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"><img src="{{asset($produto['img'])}}" alt=""></a></div>
                            <div class="product-description"><a class="product-title d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}">{{$produto['nome']}}</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
                </div>
            </div>
        </div>
        <!-- Cool Facts Area-->
        <div class="cta-area">
            <div class="container">
                <img src="img/bg-img/img9.jpg" alt="">
            </div>
        </div>
        <!-- Weekly Best Sellers-->
        <div class="weekly-best-seller-area py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="pl-1">O que você deseja..</h6><a class="btn btn-success btn-sm" href="shop-list.html">Ver todos</a>
                </div>
            <div class="row g-3">
                <!-- Single Weekly Product Card-->
                @foreach ($produtosPopulares as $produto)
                    <div class="col-12 col-md-6">
                        <div class="card weekly-product-card">
                            <div class="card-body d-flex align-items-center">
                                <div class="product-thumbnail-side"><span class="badge badge-success">Sale</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="{{ route('detalhedoproduto', $produto['cod_produto']) }}"><img src="{{asset($produto['img'])}}" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Modern Red Sofa</a>
                                    <p class="sale-price"><i class="lni lni-dollar"></i>$64<span>$89</span></p>
                                    <div class="product-rating"><i class="lni lni-star-filled"></i>4.88 (39)</div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="mr-1 lni lni-cart"></i>Compre Agora</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                
            </div>
            </div>
        </div>
        <!-- Discount Coupon Card-->
        <div class="container">
            <div class="card discount-coupon-card border-0">
            <div class="card-body">
                <div class="coupon-text-wrap d-flex align-items-center p-3">
                <h5 class="text-white pr-3 mb-0">Obtenha 20%<br>de disconto</h5>
                <p class="text-white pl-3 mb-0">detalhar informaçoes sobre<strong class="px-1">desconto</strong>na compra.</p>
                </div>
            </div>
            </div>
        </div>
        <!-- Featured Products Wrapper-->
        <div class="featured-products-wrapper py-3">
            <div class="container">
                <div class="section-heading d-flex align-items-center justify-content-between">
                    <h6 class="pl-1">Produtos em destaque</h6><a class="btn btn-warning btn-sm" href="featured-products.html">Ver todos</a>
                </div>
                <div class="row g-3">
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card featured-product-card">
                            <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                                <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/14.png" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Blue Skateboard</a>
                                    <p class="sale-price">$64<span>$89</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                    <div class="card featured-product-card">
                        <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                        <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/15.png" alt=""></a></div>
                        <div class="product-description"><a class="product-title d-block" href="single-product.html">Travel Bag</a>
                            <p class="sale-price">$64<span>$89</span></p>
                        </div>
                        </div>
                    </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                    <div class="card featured-product-card">
                        <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                        <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/16.png" alt=""></a></div>
                        <div class="product-description"><a class="product-title d-block" href="single-product">Cotton T-shirts</a>
                            <p class="sale-price">$64<span>$89</span></p>
                        </div>
                        </div>
                    </div>
                    </div>
                    <!-- Featured Product Card-->
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card featured-product-card">
                            <div class="card-body"><span class="badge badge-warning custom-badge"><i class="lni lni-star"></i></span>
                                <div class="product-thumbnail-side"><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img src="img/product/6.png" alt=""></a></div>
                                <div class="product-description"><a class="product-title d-block" href="single-product.html">Roof Lamp </a>
                                    <p class="sale-price">$64<span>$89</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Night Mode View Card-->
        <div class="night-mode-view-card pb-3">
            <div class="container">
            <div class="card settings-card">
                <div class="card-body">
                <div class="single-settings d-flex align-items-center justify-content-between">
                    <div class="title"><i class="lni lni-night"></i><span>Modo Noturno</span></div>
                    <div class="data-content">
                    <div class="toggle-button-cover">
                        <div class="button r">
                        <input class="checkbox" id="darkSwitch" type="checkbox">
                        <div class="knobs"></div>
                        <div class="layer"></div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        <!-- Internet Connection Status-->
        <div class="internet-connection-status" id="internetStatus"></div>
    </div>
@endsection


@push('scripts')
    <script src="{{ asset('js/carrinho.js') }}"></script>
@endpush