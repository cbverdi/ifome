<?php

use App\Http\Controllers\routesController;
use Illuminate\Support\Facades\Route;


Route::get('/', 'routesController@landingPage')->name('landingpage');

Route::get('/home', 'routesController@home')->name('home');

Route::get('/login', 'routesController@login')->name('login');

Route::get('/registar', 'routesController@registo')->name('registo');

Route::get('/perfil', 'routesController@perfil')->name('perfil');

Route::get('/settings', 'routesController@settings')->name('settings');

Route::get('/cart', 'routesController@cart')->name('cart');

Route::get('/notification', 'routesController@notification')->name('notification');

Route::get('/productDetail', 'routesController@productDetail')->name('productDetail');

Route::get('/detalhedoproduto/{id}', 'routesController@detalhedoproduto')->name('detalhedoproduto');

Route::prefix('meucarrinho')->name('meucarrinho.')->group(function(){

    Route::get('/', 'routesController@meucarrinho')->name('index');

    Route::post('add','routesController@add')->name('add');
    
    Route::get('remove/{rowId}', 'routesController@remove')->name('remove');
    
    Route::get('cancel','routesController@cancel')->name('cancel');

    Route::post('atualizaQty/{idItem}/{qty}', 'routesController@incrementa')->name('incrementa');

});

Route::get('/produtosDosNegocios/{identidade}', 'routesController@produtosDosNegocios')->name('produtosDosNegocios');

Route::get('/negocios/{id}', 'routesController@negocios')->name('negocios');






